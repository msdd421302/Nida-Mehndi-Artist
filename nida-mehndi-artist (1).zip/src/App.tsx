import { FirebaseProvider } from './context/FirebaseContext';
import Header from './components/Header';
import Hero from './components/Hero';
import Portfolio from './components/Portfolio';
import About from './components/About';
import Packages from './components/Packages';
import Availability from './components/Availability';
import Footer from './components/Footer';

import DecorativeDivider from './components/DecorativeDivider';

export default function App() {
  return (
    <FirebaseProvider>
      <div className="min-h-screen selection:bg-gold-500/30 selection:text-gold-300">
        <Header />
        <main>
          <Hero />
          <DecorativeDivider />
          <Portfolio />
          <DecorativeDivider />
          <About />
          <DecorativeDivider />
          <Packages />
          <DecorativeDivider />
          <Availability />
        </main>
        <Footer />
      </div>
    </FirebaseProvider>
  );
}
