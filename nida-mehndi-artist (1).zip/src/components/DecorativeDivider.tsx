export default function DecorativeDivider() {
  return (
    <div className="flex items-center justify-center gap-4 my-8 opacity-40">
      <div className="h-[1px] w-24 bg-gradient-to-r from-transparent to-gold-500" />
      <div className="relative w-4 h-4 rotate-45 border border-gold-500 flex items-center justify-center">
        <div className="w-1.5 h-1.5 bg-gold-500 rounded-full" />
      </div>
      <div className="h-[1px] w-24 bg-gradient-to-l from-transparent to-gold-500" />
    </div>
  );
}
