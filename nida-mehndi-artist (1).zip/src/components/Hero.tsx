import { motion } from 'framer-motion';
import { MapPin, Award, Heart, Home } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-burgundy-900/40 to-transparent pointer-events-none" />
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-gold-500/5 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-gold-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="container mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
        {/* Left Side: Content */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="z-10"
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="h-[1px] w-12 bg-gold-500/50" />
            <span className="text-xs uppercase tracking-[0.4em] font-medium text-gold-400">
              Premium Bridal Mehndi Artist
            </span>
            <div className="h-[1px] w-12 bg-gold-500/50" />
          </div>

          <h1 className="text-6xl md:text-8xl font-serif mb-4 leading-tight">
            <span className="block text-gold-500 gold-glow">Nida</span>
            <span className="block italic text-gold-300">Mehndi Artist</span>
          </h1>

          <p className="text-xl md:text-2xl font-light text-gold-300/60 mb-8 italic">
            Elegant Designs. Timeless Memories.
          </p>

          <div className="flex items-center gap-3 mb-10 text-gold-400/80">
            <MapPin size={18} />
            <span className="text-sm font-medium tracking-wide">📍 Bhiwandi, Maharashtra</span>
          </div>

          <div className="flex flex-col sm:flex-row gap-6 mb-12">
            <a
              href="#availability"
              className="px-8 py-4 rounded-full gold-gradient text-burgundy-950 font-bold text-sm uppercase tracking-wider hover:brightness-110 transition-all shadow-[0_0_20px_rgba(212,175,55,0.3)] text-center"
            >
              Book Your Wedding Date →
            </a>
          </div>

          {/* Service Highlights */}
          <div className="grid grid-cols-3 gap-6 pt-12 border-t border-gold-500/10">
            {[
              { icon: Award, label: "Premium Bridal Designs" },
              { icon: Heart, label: "100% Client Satisfaction" },
              { icon: Home, label: "Home & Venue Service" }
            ].map((item, i) => (
              <div key={i} className="flex flex-col items-center text-center gap-3 group">
                <div className="w-12 h-12 rounded-xl gold-border flex items-center justify-center text-gold-500 group-hover:bg-gold-500/10 transition-all">
                  <item.icon size={20} />
                </div>
                <span className="text-[10px] uppercase tracking-wider text-gold-300/70 font-medium leading-relaxed">
                  {item.label}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Right Side: Visual */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative lg:h-[80vh] flex items-center justify-center"
        >
          <div className="relative w-full h-full max-w-lg lg:max-w-none">
            {/* Main Bride Image */}
            <div className="relative z-10 w-full h-full rounded-[2rem] overflow-hidden gold-border shadow-2xl">
              <img
                src="/src/assets/images/hero_bride_mehndi_1794427505834.jpg"
                alt="Beautiful bride with intricate mehndi"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-1000"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-burgundy-950/60 via-transparent to-transparent" />
            </div>

            {/* Decorative Gold Frames */}
            <div className="absolute -top-4 -right-4 w-full h-full rounded-[2rem] border border-gold-500/20 pointer-events-none" />
            <div className="absolute -bottom-4 -left-4 w-full h-full rounded-[2rem] border border-gold-500/10 pointer-events-none" />
            
            {/* Soft Glowing Light */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-gold-500/10 rounded-full blur-[120px] -z-10" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
