import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ZoomIn } from 'lucide-react';

const portfolioItems = [
  {
    id: 1,
    title: 'Traditional Bridal',
    image: '/src/assets/images/portfolio_traditional_full_1794427506479.jpg',
    category: 'Full Hand Designs'
  },
  {
    id: 2,
    title: 'Arabic Bridal',
    image: '/src/assets/images/portfolio_arabic_bridal_1794427506377.jpg',
    category: 'Floral & Minimalist'
  },
  {
    id: 3,
    title: 'Portrait Mehndi',
    image: '/src/assets/images/portfolio_portrait_bridal_mehndi_1794427506184.jpg',
    category: 'Custom Art'
  },
  {
    id: 4,
    title: 'Detailed Feet',
    image: '/src/assets/images/portfolio_feet_mehndi_design_1794427507508.jpg',
    category: 'Traditional'
  },
  {
    id: 5,
    title: 'Mandala Art',
    image: '/src/assets/images/portfolio_mandala_mehndi_art_1794427507324.jpg',
    category: 'Geometric'
  }
];

export default function Portfolio() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  return (
    <section id="portfolio" className="py-24 bg-burgundy-900/30">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex flex-col items-center"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="h-[1px] w-12 bg-gold-500/50" />
              <h2 className="text-4xl md:text-5xl font-serif text-gold-500">Our Mehndi Portfolio</h2>
              <div className="h-[1px] w-12 bg-gold-500/50" />
            </div>
            <p className="text-gold-300/60 italic">Art that speaks love.</p>
          </motion.div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {portfolioItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative cursor-pointer"
              onClick={() => setSelectedImage(item.image)}
            >
              <div className="relative aspect-[4/3] rounded-2xl overflow-hidden gold-border shadow-lg">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-burgundy-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
                  <div className="w-12 h-12 rounded-full gold-gradient flex items-center justify-center text-burgundy-950 shadow-xl">
                    <ZoomIn size={20} />
                  </div>
                </div>
              </div>
              <div className="mt-4 text-center">
                <h3 className="text-gold-400 font-serif text-lg">{item.title}</h3>
                <p className="text-[10px] uppercase tracking-widest text-gold-300/50">{item.category}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <button className="px-8 py-3 rounded-full border border-gold-500/30 text-gold-400 hover:bg-gold-500/10 transition-all font-medium text-sm tracking-wide">
            View More Designs →
          </button>
        </div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-burgundy-950/95 backdrop-blur-xl"
            onClick={() => setSelectedImage(null)}
          >
            <button
              className="absolute top-8 right-8 text-gold-400 hover:text-gold-300 transition-colors"
              onClick={() => setSelectedImage(null)}
            >
              <X size={32} />
            </button>
            
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="max-w-5xl w-full aspect-[4/3] rounded-3xl overflow-hidden gold-border shadow-[0_0_50px_rgba(212,175,55,0.2)]"
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={selectedImage}
                alt="Selected portfolio design"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
