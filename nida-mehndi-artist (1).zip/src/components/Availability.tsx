import { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, CheckCircle, MessageSquare, Star, ArrowRight } from 'lucide-react';
import { useFirebase } from '../context/FirebaseContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

export default function Availability() {
  const { user, signIn } = useFirebase();
  const [weddingDate, setWeddingDate] = useState('');
  const [packageName, setPackageName] = useState('Premium');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      await signIn();
      return;
    }

    if (!weddingDate) return;

    setIsSubmitting(true);
    try {
      const bookingData = {
        userId: user.uid,
        userName: user.displayName || 'Anonymous User',
        userEmail: user.email || 'no-email@provided.com',
        weddingDate,
        packageName,
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      await addDoc(collection(db, 'bookings'), bookingData);
      setShowSuccess(true);
      
      // WhatsApp Integration
      const phone = "+919876543210";
      const message = `Hello Nida Mehndi Artist, I'd like to book a slot for my wedding on ${weddingDate}. I'm interested in the ${packageName} package. My name is ${user.displayName}.`;
      const whatsappUrl = `https://wa.me/${phone.replace('+', '')}?text=${encodeURIComponent(message)}`;
      
      setTimeout(() => {
        window.open(whatsappUrl, '_blank');
      }, 2000);

    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'bookings');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="availability" className="py-24 bg-burgundy-950">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          
          {/* Left Side: Check Availability */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-burgundy-900/40 p-10 rounded-[3rem] gold-border shadow-2xl relative overflow-hidden"
          >
            {/* Decorative BG */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-gold-500/5 rounded-full blur-3xl" />
            
            <h2 className="text-4xl font-serif text-gold-500 mb-4">Check Availability</h2>
            <p className="text-gold-300/60 mb-10">Select your wedding date and get instant confirmation via WhatsApp.</p>

            {showSuccess ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-12"
              >
                <div className="w-20 h-20 bg-gold-500/20 rounded-full flex items-center justify-center text-gold-500 mx-auto mb-6">
                  <CheckCircle size={40} />
                </div>
                <h3 className="text-2xl font-serif text-gold-400 mb-4">Booking Request Sent!</h3>
                <p className="text-gold-300/60 mb-8">Redirecting you to WhatsApp to finalize your booking with Nida.</p>
                <button 
                  onClick={() => setShowSuccess(false)}
                  className="text-gold-500 underline text-sm"
                >
                  Make another request
                </button>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-gold-300/50 mb-2 ml-4">Wedding Date</label>
                  <div className="relative">
                    <input
                      type="date"
                      required
                      value={weddingDate}
                      onChange={(e) => setWeddingDate(e.target.value)}
                      className="w-full bg-burgundy-950 border border-gold-500/20 rounded-2xl py-4 px-6 text-gold-300 focus:outline-none focus:border-gold-500/50 transition-colors [color-scheme:dark]"
                    />
                    <Calendar className="absolute right-6 top-1/2 -translate-y-1/2 text-gold-500/30 pointer-events-none" size={20} />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-gold-300/50 mb-2 ml-4">Select Package</label>
                  <select
                    value={packageName}
                    onChange={(e) => setPackageName(e.target.value)}
                    className="w-full bg-burgundy-950 border border-gold-500/20 rounded-2xl py-4 px-6 text-gold-300 focus:outline-none focus:border-gold-500/50 transition-colors appearance-none"
                  >
                    <option value="Classic">Classic Bridal Package</option>
                    <option value="Premium">Premium Bridal Package</option>
                    <option value="Royal">Royal Bridal Package</option>
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 rounded-2xl gold-gradient text-burgundy-950 font-bold uppercase tracking-widest flex items-center justify-center gap-3 hover:brightness-110 transition-all disabled:opacity-50 shadow-lg mt-4"
                >
                  {isSubmitting ? 'Checking...' : (user ? 'Check Availability →' : 'Sign in to Book →')}
                </button>
                
                <p className="text-[10px] text-center text-gold-300/40 uppercase tracking-widest mt-6 italic">
                  * Final availability requires artist confirmation.
                </p>
              </form>
            )}
          </motion.div>

          {/* Right Side: Testimonials */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex flex-col justify-center"
          >
            <div className="flex items-center gap-4 mb-6">
              <div className="h-[1px] w-12 bg-gold-500/50" />
              <span className="text-xs uppercase tracking-[0.4em] font-medium text-gold-400">Reviews</span>
            </div>

            <h2 className="text-4xl md:text-5xl font-serif text-gold-500 mb-12">What Our Clients Say</h2>

            <div className="space-y-12">
              <div className="relative bg-burgundy-900/20 p-8 rounded-3xl border-l-2 border-gold-500/30">
                <div className="flex gap-1 mb-6">
                  {[1, 2, 3, 4, 5].map((s) => <Star key={s} size={16} className="fill-gold-500 text-gold-500" />)}
                </div>
                <p className="text-xl text-gold-300/80 italic mb-8 leading-relaxed">
                  "Nida did an amazing job on my wedding mehndi! The designs were just perfect and lasted so well. Everyone at the wedding was asking about the artist. Highly recommended for any bride!"
                </p>
                <div className="flex items-center gap-4">
                  <img
                    src="/src/assets/images/testimonial_bride_face_1794427507772.jpg"
                    alt="Happy Client"
                    className="w-14 h-14 rounded-full gold-border"
                  />
                  <div>
                    <h4 className="text-gold-400 font-serif text-lg">Ayesha Khan</h4>
                    <p className="text-[10px] uppercase tracking-widest text-gold-300/50">Bhiwandi, Maharashtra</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-8 px-4">
                <div className="flex flex-col">
                  <span className="text-4xl font-serif text-gold-500">500+</span>
                  <span className="text-[10px] uppercase tracking-widest text-gold-300/50">Happy Brides</span>
                </div>
                <div className="h-12 w-[1px] bg-gold-500/20" />
                <div className="flex flex-col">
                  <span className="text-4xl font-serif text-gold-500">4.9/5</span>
                  <span className="text-[10px] uppercase tracking-widest text-gold-300/50">Average Rating</span>
                </div>
              </div>
            </div>

            <div className="mt-12 flex items-center gap-4 text-gold-400 group cursor-pointer">
              <span className="font-bold text-sm tracking-widest uppercase">Read More Reviews</span>
              <ArrowRight size={20} className="group-hover:translate-x-2 transition-transform" />
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
