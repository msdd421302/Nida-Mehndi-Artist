import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-24 relative overflow-hidden">
      {/* Background Illustrations */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 opacity-10 pointer-events-none">
        <svg width="400" height="600" viewBox="0 0 400 600" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M50 550C50 550 150 450 250 500C350 550 450 450 450 450" stroke="#d4af37" strokeWidth="2" strokeLinecap="round" />
          <circle cx="50" cy="550" r="10" stroke="#d4af37" strokeWidth="2" />
          <circle cx="250" cy="500" r="15" stroke="#d4af37" strokeWidth="2" />
          <path d="M100 100C150 150 200 50 300 100" stroke="#d4af37" strokeWidth="1" strokeDasharray="5 5" />
        </svg>
      </div>

      <div className="container mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
        {/* Left Side: Visual */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="relative"
        >
          <div className="aspect-[3/2] rounded-[2.5rem] overflow-hidden gold-border shadow-2xl relative z-10">
            <img
              src="/src/assets/images/about_mehndi_artist_work_1794427507198.jpg"
              alt="Mehndi application process"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-tr from-burgundy-950/40 to-transparent" />
          </div>
          
          {/* Floating Element */}
          <motion.div
            animate={{ y: [0, -20, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -bottom-8 -right-8 w-48 h-48 bg-burgundy-900/80 backdrop-blur-lg rounded-3xl gold-border p-6 shadow-2xl z-20 flex flex-col items-center justify-center text-center"
          >
            <span className="text-3xl font-serif text-gold-500 mb-1">10+</span>
            <span className="text-[10px] uppercase tracking-widest text-gold-300/70 leading-tight">Years of<br />Excellence</span>
          </motion.div>

          <div className="absolute -top-10 -left-10 w-64 h-64 border border-gold-500/10 rounded-full" />
        </motion.div>

        {/* Right Side: Content */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="h-[1px] w-12 bg-gold-500/50" />
            <span className="text-xs uppercase tracking-[0.4em] font-medium text-gold-400">The Artist</span>
          </div>

          <h2 className="text-4xl md:text-5xl font-serif text-gold-500 mb-8">About Nida Mehndi Artist</h2>
          
          <p className="text-gold-300/70 text-lg leading-relaxed mb-8">
            With a passion for art and a commitment to perfection, Nida Mehndi Artist brings you stunning bridal mehndi designs that make your special moments even more memorable. Every stroke is a reflection of tradition, elegance, and your unique personality.
          </p>

          <div className="space-y-4 mb-10">
            {[
              "Expert in Bridal & Arabic Mehndi",
              "Customized Designs & Portraits",
              "On-Time & Professional Service",
              "High-Quality Organic Henna"
            ].map((feature) => (
              <div key={feature} className="flex items-center gap-4">
                <div className="w-6 h-6 rounded-full bg-gold-500/20 flex items-center justify-center text-gold-400">
                  <Check size={14} />
                </div>
                <span className="text-gold-300/80 font-medium">{feature}</span>
              </div>
            ))}
          </div>

          <button className="px-8 py-4 rounded-full border border-gold-500/30 text-gold-400 hover:bg-gold-500/10 transition-all font-bold text-sm tracking-widest">
            KNOW MORE ABOUT ME →
          </button>
        </motion.div>
      </div>
    </section>
  );
}
