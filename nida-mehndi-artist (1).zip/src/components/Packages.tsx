import { motion } from 'framer-motion';
import { Diamond, Star, Crown } from 'lucide-react';

const packages = [
  {
    name: 'Classic Bridal Package',
    icon: Diamond,
    price: '₹7,999',
    features: [
      'Full Hand Mehndi (Front & Back)',
      'Basic Feet Designs',
      'Traditional Patterns',
      'Organic Henna Provided'
    ],
    popular: false
  },
  {
    name: 'Premium Bridal Package',
    icon: Crown,
    price: '₹11,999',
    features: [
      'Full Hand + Feet Mehndi',
      'Intricate Arabic Accents',
      'Custom Pattern Selection',
      'Complimentary Sangeet Session'
    ],
    popular: true
  },
  {
    name: 'Royal Bridal Package',
    icon: Star,
    price: '₹15,999',
    features: [
      'Custom Portraits (Bride & Groom)',
      'Royal Mandala Patterns',
      'Heavy Feet Art',
      'Priority Booking & Consultation'
    ],
    popular: false
  }
];

export default function Packages() {
  return (
    <section id="packages" className="py-24 bg-burgundy-900/50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex flex-col items-center"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="h-[1px] w-12 bg-gold-500/50" />
              <h2 className="text-4xl md:text-5xl font-serif text-gold-500">Our Bridal Packages</h2>
              <div className="h-[1px] w-12 bg-gold-500/50" />
            </div>
            <p className="text-gold-300/60 italic">Choose the perfect package for your big day.</p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {packages.map((pkg, index) => (
            <motion.div
              key={pkg.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`relative p-8 rounded-[2.5rem] flex flex-col items-center text-center transition-all duration-500 group ${
                pkg.popular 
                ? 'bg-gold-300 text-burgundy-950 scale-105 shadow-[0_0_40px_rgba(212,175,55,0.3)] z-10' 
                : 'bg-burgundy-900/40 text-gold-300 border border-gold-500/20 hover:border-gold-500/50'
              }`}
            >
              {pkg.popular && (
                <div className="absolute -top-4 right-8 bg-[#c41e3a] text-white text-[10px] font-bold px-4 py-1.5 rounded-full uppercase tracking-widest shadow-xl">
                  Most Popular
                </div>
              )}

              <div className={`w-16 h-16 rounded-2xl mb-6 flex items-center justify-center transition-colors ${
                pkg.popular ? 'bg-burgundy-900/10' : 'bg-gold-500/10'
              }`}>
                <pkg.icon size={32} className={pkg.popular ? 'text-burgundy-950' : 'text-gold-500'} />
              </div>

              <h3 className={`text-2xl font-serif mb-2 ${pkg.popular ? 'text-burgundy-950' : 'text-gold-400'}`}>
                {pkg.name}
              </h3>
              
              <div className="text-3xl font-bold mb-8 font-sans">
                {pkg.price}
              </div>

              <ul className="space-y-4 mb-10 flex-grow">
                {pkg.features.map((feature) => (
                  <li key={feature} className={`text-sm ${pkg.popular ? 'text-burgundy-950/80' : 'text-gold-300/60'}`}>
                    {feature}
                  </li>
                ))}
              </ul>

              <a
                href="#availability"
                className={`w-full py-4 rounded-2xl font-bold text-sm uppercase tracking-widest transition-all ${
                  pkg.popular 
                  ? 'bg-burgundy-950 text-gold-300 hover:brightness-125' 
                  : 'gold-gradient text-burgundy-950 hover:brightness-110'
                }`}
              >
                Book Now →
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
