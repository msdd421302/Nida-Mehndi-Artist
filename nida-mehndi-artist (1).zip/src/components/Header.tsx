import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, Menu, X, LogIn, LogOut, User as UserIcon } from 'lucide-react';
import { useFirebase } from '../context/FirebaseContext';

export default function Header() {
  const { user, signIn, signOut } = useFirebase();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Portfolio', href: '#portfolio' },
    { name: 'Packages', href: '#packages' },
    { name: 'About', href: '#about' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-burgundy-950/90 backdrop-blur-md py-3 shadow-lg' : 'bg-transparent py-6'
      }`}
    >
      <div className="container mx-auto px-6 flex items-center justify-between gap-8">
        {/* Brand Zone */}
        <a href="#home" className="flex items-center gap-3 shrink-0">
          <div className="w-10 h-10 rounded-full gold-gradient flex items-center justify-center">
            <span className="text-burgundy-950 font-display font-bold text-xl">N</span>
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-display font-bold tracking-wider text-gold-400 whitespace-nowrap">Nida</span>
            <span className="text-[10px] tracking-[0.2em] uppercase text-gold-300/70 -mt-1">Mehndi Artist</span>
          </div>
        </a>

        {/* Nav Links - Center */}
        <nav className="hidden lg:flex items-center gap-8 text-sm font-medium">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-gold-300/80 hover:text-gold-400 transition-colors whitespace-nowrap shrink-0 relative group"
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gold-400 transition-all group-hover:w-full" />
            </a>
          ))}
        </nav>

        {/* Actions - Right */}
        <div className="flex items-center gap-4 shrink-0">
          {user ? (
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex flex-col items-end">
                <span className="text-xs text-gold-300 truncate max-w-[100px]">{user.displayName || 'User'}</span>
                <button onClick={signOut} className="text-[10px] text-gold-500 hover:text-gold-400 underline">Sign Out</button>
              </div>
              {user.photoURL ? (
                <img src={user.photoURL} alt={user.displayName || ''} className="w-8 h-8 rounded-full border border-gold-500/50" />
              ) : (
                <div className="w-8 h-8 rounded-full border border-gold-500/50 flex items-center justify-center">
                  <UserIcon size={16} />
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={signIn}
              className="hidden sm:flex items-center gap-2 text-xs font-medium text-gold-300 hover:text-gold-400 transition-colors"
            >
              <LogIn size={16} />
              Sign In
            </button>
          )}

          <a
            href="#availability"
            className="hidden md:flex items-center gap-2 px-5 py-2.5 rounded-full gold-gradient text-burgundy-950 font-bold text-xs uppercase tracking-wider hover:brightness-110 transition-all shadow-lg whitespace-nowrap shrink-0"
          >
            Book Your Slot
            <Calendar size={14} />
          </a>

          {/* Mobile Menu Toggle */}
          <button
            className="lg:hidden text-gold-400"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-burgundy-900 border-t border-gold-500/10"
          >
            <div className="container mx-auto px-6 py-8 flex flex-col gap-6">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-lg font-serif text-gold-300 hover:text-gold-400"
                >
                  {link.name}
                </a>
              ))}
              <div className="pt-4 border-t border-gold-500/10 flex flex-col gap-4">
                {user ? (
                  <button onClick={signOut} className="flex items-center gap-3 text-gold-300">
                    <LogOut size={20} />
                    Sign Out
                  </button>
                ) : (
                  <button onClick={signIn} className="flex items-center gap-3 text-gold-300">
                    <LogIn size={20} />
                    Sign In
                  </button>
                )}
                <a
                  href="#availability"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center justify-center gap-2 px-6 py-3 rounded-full gold-gradient text-burgundy-950 font-bold text-sm uppercase tracking-wider"
                >
                  Book Your Slot
                  <Calendar size={16} />
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
