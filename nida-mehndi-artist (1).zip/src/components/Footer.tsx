import { Instagram, Facebook, Youtube, MessageCircle, Mail, MapPin, Phone } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer id="contact" className="bg-burgundy-950 pt-24 pb-12 border-t border-gold-500/10">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          {/* Logo & About */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full gold-gradient flex items-center justify-center">
                <span className="text-burgundy-950 font-display font-bold text-2xl">N</span>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-display font-bold tracking-wider text-gold-400">Nida</span>
                <span className="text-xs tracking-[0.2em] uppercase text-gold-300/70 -mt-1">Mehndi Artist</span>
              </div>
            </div>
            <p className="text-gold-300/50 text-sm leading-relaxed">
              Bringing luxury bridal mehndi art to your doorstep. Every design is a masterpiece crafted with love and tradition.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h4 className="text-gold-500 font-serif text-xl">Quick Links</h4>
            <ul className="space-y-4 text-sm text-gold-300/60">
              <li><a href="#home" className="hover:text-gold-400 transition-colors">Home</a></li>
              <li><a href="#portfolio" className="hover:text-gold-400 transition-colors">Portfolio</a></li>
              <li><a href="#packages" className="hover:text-gold-400 transition-colors">Bridal Packages</a></li>
              <li><a href="#about" className="hover:text-gold-400 transition-colors">About Me</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-6">
            <h4 className="text-gold-500 font-serif text-xl">Contact Us</h4>
            <ul className="space-y-4 text-sm text-gold-300/60">
              <li className="flex items-center gap-3">
                <MapPin size={18} className="text-gold-500" />
                <span>Bhiwandi, Maharashtra</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-gold-500" />
                <a href="tel:+919876543210" className="hover:text-gold-400 transition-colors">+91 98765 43210</a>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-gold-500" />
                <a href="mailto:info@nidamehndi.com" className="hover:text-gold-400 transition-colors">info@nidamehndi.com</a>
              </li>
            </ul>
          </div>

          {/* Social Media */}
          <div className="space-y-6">
            <h4 className="text-gold-500 font-serif text-xl">Follow Us</h4>
            <div className="flex gap-4">
              {[
                { icon: Instagram, href: '#' },
                { icon: Facebook, href: '#' },
                { icon: Youtube, href: '#' },
                { icon: MessageCircle, href: '#' }
              ].map((social, i) => (
                <a
                  key={i}
                  href={social.href}
                  className="w-10 h-10 rounded-full border border-gold-500/20 flex items-center justify-center text-gold-300 hover:bg-gold-500 hover:text-burgundy-950 transition-all"
                >
                  <social.icon size={20} />
                </a>
              ))}
            </div>
            <a
              href="https://wa.me/919876543210"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#25D366] text-white font-bold text-sm hover:brightness-110 transition-all shadow-lg"
            >
              <MessageCircle size={20} />
              WhatsApp Us
            </a>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-gold-500/10 flex flex-col md:flex-row items-center justify-between gap-6 text-center">
          <p className="text-[10px] uppercase tracking-widest text-gold-300/30">
            © {currentYear} Nida Mehndi Artist. All Rights Reserved.
          </p>
          <div className="flex items-center gap-6 text-[10px] uppercase tracking-widest text-gold-300/30">
            <a href="#" className="hover:text-gold-400">Privacy Policy</a>
            <a href="#" className="hover:text-gold-400">Terms of Service</a>
          </div>
          <div className="flex flex-col items-center gap-2">
             <div className="h-[1px] w-12 bg-gold-500/20" />
             <p className="text-[8px] uppercase tracking-[0.4em] text-gold-500/40 italic">Handcrafted with Love</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
